package com.cg.dao;

import java.util.Date;

import com.cg.bean.AccountDetails;

public interface IBankDao{
	public boolean login(Integer userID, String loginPassword,AccountDetails ad);
	public void miniStatement(AccountDetails ad);
	public void detailedStatement(Date from, Date to,AccountDetails ad);
	public void changeDetails(AccountDetails ad);
	public void chequeBookRequest(AccountDetails ad);
	public void trackServiceRequest(AccountDetails ad);
	public void fundTransfer(AccountDetails ad);
	public void changePassword(AccountDetails ad);
	public void createNewAccount(AccountDetails ad);
	public void viewAllTransactions();
	public boolean forgetPassword(AccountDetails ad,String secretanswer);
}
