package com.cg.bean;

import java.math.BigInteger;

public class PayeeTable {
	private String nickName;
	private BigInteger payeeAccountID;
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public BigInteger getPayeeAccountID() {
		return payeeAccountID;
	}
	public void setPayeeAccountID(BigInteger payeeAccountID) {
		this.payeeAccountID = payeeAccountID;
	}
	
}
