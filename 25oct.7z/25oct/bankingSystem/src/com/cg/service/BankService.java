package com.cg.service;

import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.cg.bean.AccountDetails;
import com.cg.dao.BankDao;

import java.util.Date;

class ViewStatement{
	ViewStatement(BankDao bd,AccountDetails ad){
		System.out.println("Choose a option \n");
		System.out.println("1--View Mini statement");
		System.out.println("2--View Detailed statement");
		Scanner ss = new Scanner(System.in);
		Integer n = ss.nextInt();
		
		//to view statements of all his/her accounts, incase of multiple accounts
		switch(n)
		{
			case 1: 
				bd.miniStatement(ad);
				break;
			case 2:
				System.out.println("Enter range for dates");
				System.out.println("From Date(format- dd-mm-yyyy)");
				String fr= ss.next();
				System.out.println("TO Date(format- dd-mm-yyyy)");
				String t= ss.next();
				Date from = null;
				Date to = null;
			try {
				from = new SimpleDateFormat("dd-mm-yyyy").parse(fr);
				to=new SimpleDateFormat("dd-mm-yyyy").parse(t);
			} catch (ParseException e) {
				e.printStackTrace();
			}
				bd.detailedStatement(from,to,ad);
				break;
			default:
		}
		ss.close();
	}
	public void miniStatement(){
	
	}
	public void detailedStatement(Date from, Date to){
		
	}
}

public class BankService implements IBankService{
	
	BankDao bd= new BankDao();
	@Override
	public boolean login(Integer  userID, String loginPassword,AccountDetails ad) {
		
		return bd.login(userID, loginPassword,ad);
	}

	@Override
	public void viewStatement(AccountDetails ad) {
		ViewStatement vs = new ViewStatement(bd,ad);
	}

	@Override
	public void changeDetails(AccountDetails ad) {
		bd.changeDetails(ad);
		
		
	}

	@Override
	public void chequeBookRequest(AccountDetails ad) {
		bd.chequeBookRequest(ad);
		
	}

	@Override
	public void trackServiceRequest(AccountDetails ad) {
		bd.trackServiceRequest(ad);
		
	}

	@Override
	public void fundTransfer(AccountDetails ad) {
		System.out.println("Choose a option \n");
		System.out.println("1--Own  bank account ");
		System.out.println("2--Other  account of same bank");
		Scanner ss1 = new Scanner(System.in);
		Integer n1 = ss1.nextInt();
		//to view statements of all his/her accounts, incase of multiple accounts
		switch(n1)
		{
			case 1: 
				//This accepts from Account and To account no   For fund transfer. 
				break;
			case 2:
				bd.fundTransfer(ad);
				break;
			default:System.out.println("\nWrong choice. Choose between 1-2");
		}
	
		
		
	}

	@Override
	public void changePassword(AccountDetails ad) {
		bd.changePassword(ad);
		
	}

	@Override
	public void createNewAccount(AccountDetails ad) {
		bd.createNewAccount(ad);
		
	}

	@Override
	public void viewAllTransactions() {
		bd.viewAllTransactions();
		
	}

	@Override
	public boolean forgetPassword(AccountDetails ad,String secretanswer) {
		return bd.forgetPassword(ad,secretanswer);
		
	}
}
