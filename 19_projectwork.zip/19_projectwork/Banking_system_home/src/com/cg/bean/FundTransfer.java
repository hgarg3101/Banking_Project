package com.cg.bean;

import java.math.BigInteger;
import java.util.Date;

public class FundTransfer {
	private Integer fundTransferID;
	private Date dateOfTransfer =new Date();
	private Double transferAmount;
	private PayeeTable payeeTable=new PayeeTable();
	public Integer getFundTransferID() {
		return fundTransferID;
	}
	public void setFundTransferID(Integer fundTransferID) {
		this.fundTransferID = fundTransferID;
	}
	public Date getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(Date dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public Double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(Double transferAmount) {
		this.transferAmount = transferAmount;
	}
	public PayeeTable getPayeeTable() {
		return payeeTable;
	}
	public void setPayeeTable(PayeeTable payeeTable) {
		this.payeeTable = payeeTable;
	}
	
	
}
