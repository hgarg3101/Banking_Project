package com.cg.service;

import com.cg.bean.AccountDetails;


public interface IBankService {
	
	public boolean login(Integer  userID, String loginPassword,AccountDetails ad);
	public void viewStatement(AccountDetails ad);
	public void changeDetails(AccountDetails ad);
	public void chequeBookRequest(AccountDetails ad);
	public void trackServiceRequest(AccountDetails ad);
	public void fundTransfer(AccountDetails ad);
	public void changePassword(AccountDetails ad);
	public void createNewAccount(AccountDetails ad);
	public void viewAllTransactions();
}
