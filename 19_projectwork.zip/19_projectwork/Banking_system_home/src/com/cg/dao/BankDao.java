package com.cg.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.cg.bean.AccountDetails;

public class BankDao implements IBankDao {
	public Connection getConnection(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
		try {
			return DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean login(Integer userID, String loginPassword,AccountDetails ad) {
		boolean flag=false;
		Connection con = getConnection();
		String sql1="select * from user_table where user_id=?";   //userId validation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, userID);
		  //remember sequence needed
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				if(rs.getString(3).equals(loginPassword)){
					ad.setAccount_ID(BigInteger.valueOf(rs.getInt(1)));//change here
					ad.getUserTable().setUserID(userID.toString());
					ad.getUserTable().setLoginPassword(loginPassword);
					ad.getUserTable().setSecretQuestion(rs.getString(4));
					ad.getUserTable().setTransactionPassword(rs.getString(5));
					ad.getUserTable().setLockStatus(rs.getString(6));
					if(ad.getUserTable().getLockStatus().toUpperCase()=="N") {
						System.out.println("Account is locked!! Contact branch manager");
						System.exit(0);
					}else {
						flag=true;
					}
				}
			}
			
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		//home
		
		String sql2="select * from account_master where account_id=?";  
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql2);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				ad.setAccountType(rs.getString(2));
				ad.setAccountBalance(rs.getDouble(3));
				ad.setOpenDate(rs.getDate(4));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	@Override
	public void miniStatement(AccountDetails ad) {
		Connection con = getConnection();
		String sql="select * from transactions where rownum<=10 & account_id=? order by Transaction_ID desc";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void detailedStatement(Date from, Date to,AccountDetails ad) {
		Connection con = getConnection();
		String sql="select * from transactions where account_id=? & TO_DATE(TO_CHAR(DateOfTransaction, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN ? AND ? order by Transaction_ID desc";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
			ps.setDate(2, new java.sql.Date(from.getTime()));
			ps.setDate(3, new java.sql.Date(to.getTime()));
			  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void changeDetails(AccountDetails ad) {
		Connection con = getConnection();
		Scanner ss= new Scanner(System.in);
		String sql1="select * from customer where account_id=(select account_id from user_table where user_id=?)";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, Integer.valueOf(ad.getUserTable().getUserID()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("Email:"+rs.getString(3));
				System.out.println("Address:"+rs.getString(4));
			}
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
	String sql2= "update customer set email=?,address=? where account_id=(select account_id from user_table where user_id=?)";
	System.out.println("Enter new email");
	String newemail=ss.next();
	System.out.println("Enter new address");
	String newaddress=ss.next();
	try {
		PreparedStatement ps  = con.prepareStatement(sql2);
		ps.setString(1, newemail);
		ps.setString(2, newaddress);
		ps.setInt(3, Integer.valueOf(ad.getUserTable().getUserID()));	
		Integer n= ps.executeUpdate();
		if(n>=1){
			System.out.println("New data updated");
		}
		con.close();
		ss.close();
	}	
	catch (SQLException e) {
		e.printStackTrace();
	}
	}

	@Override
	public void chequeBookRequest(AccountDetails ad) {
		Date serviceRaisedDate = new Date();
		Connection con = getConnection();
		String sql1="select bank_cheque_seq.nextval from dual";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
		  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				ad.getServiceTracker().setService_ID(rs.getInt(1));
			}
			ad.getServiceTracker().setServiceDescription("cheque book request");
			ad.getServiceTracker().setServiceRaisedDate(serviceRaisedDate);
			ad.getServiceTracker().setServiceStatus("Open");
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sql2="insert into service_tracker values(?,?,?,?,?) ";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql2);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
			ps.setInt(2,ad.getServiceTracker().getService_ID());
			ps.setString(3, ad.getServiceTracker().getServiceDescription());	
			ps.setDate(4, new java.sql.Date(ad.getServiceTracker().getServiceRaisedDate().getTime()));
			ps.setString(5, ad.getServiceTracker().getServiceStatus());
			Integer n= ps.executeUpdate();
			if(n>=1){
				System.out.println("service request generated");
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	

		
	}

	@Override
	public void trackServiceRequest(AccountDetails ad) {
		Scanner ss= new Scanner(System.in);
		Connection con = getConnection();
		System.out.println("Please enter service request id");
		
		String sql1="select * from service_tracker where user_id=? & account_id=?";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, Integer.valueOf((ss.next())));
			ps.setInt(2, Integer.valueOf(ad.getAccount_ID().toString()));
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
				System.out.println("service status:  "+rs.getString(5));
				
			}
			else {
				//code here realted to 20 transactions
				System.out.println();
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void fundTransfer(AccountDetails ad) {
		Scanner ss1 = new Scanner(System.in);
		System.out.println("\nMake a Transfer\n\n");
		System.out.println("Choose a option \n");
		System.out.println("1--Add a Payee ");
		System.out.println("2--Pay to payee");
		Integer n2 = ss1.nextInt();
			switch(n2) {
			case 1:{
				System.out.println("Enter payee account id ");
				String payee= ss1.next();
				System.out.println("Ener nick name for payee");
				String nick = ss1.next();
				Connection con = getConnection();
				String sql1="selet * from payeetable where account_id=?";

				try {
					PreparedStatement ps  = con.prepareStatement(sql1);
					ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
					ResultSet rs= ps.executeQuery();
					while(rs.next()){
						if(rs.getInt(2)==Integer.valueOf(payee)) {
							System.out.println("Payee account id already exist for your account");
							break;
						}
						else {
							String sql2="insert into payeetable values(?,?,?)";   //userId validation
							
							try {
								PreparedStatement ps2  = con.prepareStatement(sql2);
								ps2.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
								ps2.setInt(2,Integer.valueOf(payee));
								ps2.setString(3,nick);
								Integer n= ps2.executeUpdate();
								if(n>=1){
									System.out.println("! row updated in paye table");
								}
								else {
									//code here 
									System.out.println();
								}
								con.close();
							}	
							catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
						
					}
					
				}	
				catch (SQLException e) {
					e.printStackTrace();
				}
			break;
			}
			case 2:{
				Integer count=0;
				System.out.println("Enter payee account id ");
				ad.getPayeeTable().setPayeeAccountID(BigInteger.valueOf(ss1.nextLong()));
				System.out.println("Enter the transaction amount: ");
				ad.getTransactiondetails().setTranAmount(ss1.nextDouble());
				System.out.println("Enter the transaction password: ");
				String tpass=ss1.next();
				while(true) {
				if(!(ad.getUserTable().getTransactionPassword()).equals(tpass)) {
					System.out.println("Wrong password!!! "+count+" more chances left to enter correct password");
					count++;
					if(count==3){
						try {
							Connection con = getConnection();
							String sql="update usertable set lock_status=? where account_id=? & payee_account_id=?";
							PreparedStatement ps= con.prepareStatement(sql);
							ps.setString(1, "N");
							ps.setInt(2, Integer.valueOf(ad.getAccount_ID().toString()));
							ps.setInt(3,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
							Integer n= ps.executeUpdate();
							if(n>=1) {
								System.out.println("Account locked!!! \n You have entered wrong password 3 times. Contact branch manager");
							}
							con.close();
						}
						catch(Exception e) {
							e.printStackTrace();
						}
						
					}
					else if(count<=3) {
						System.out.println("Enter password again");
						continue;
					}
				}
				else {
					
					//pay the payee
					//validation to check balance in account
					try {
						if(ad.getTransactiondetails().getTranAmount()>ad.getAccountBalance()) {
							System.out.println("Insufficient balance!! You have Rs."+ad.getAccountBalance()+" only in your account");		
						}
						else {
							Connection con = getConnection();
							String sql1="select * from account_master where account_id=?";
							PreparedStatement ps1= con.prepareStatement(sql1);
							ps1.setInt(1,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
							ResultSet rs= ps1.executeQuery();
							while(rs.next()) {
								ad.setAccountBalance(ad.getAccountBalance()-ad.getTransactiondetails().getTranAmount()); //deducting amount for payment
								ad.getTransactiondetails().setTranAmount(ad.getTransactiondetails().getTranAmount()+rs.getDouble(3)); //adding amount for payment
								
							}
							String sql2="update AccountMaster set account_balance=? where account_id=?";
							PreparedStatement ps2= con.prepareStatement(sql2);
							ps2.setDouble(1, ad.getTransactiondetails().getTranAmount());
							ps2.setInt(2,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
							Integer n= ps2.executeUpdate();
							if(n>=1) {
								System.out.println("Amount added to payee account");
							}
							String sql3="update AccountMaster set account_balance=? where account_id=?";
							PreparedStatement ps3= con.prepareStatement(sql3);
							ps3.setDouble(1, ad.getAccountBalance());
							ps3.setInt(2,Integer.valueOf(ad.getAccount_ID().toString()));
							Integer n3= ps3.executeUpdate();
							if(n3>=1) {
								System.out.println("Amount dedcuted from your account");
							}
							con.close();
						}
						//deduct amount code
						
						
					}
					catch(Exception e) {
						e.printStackTrace();
						}
					}
				break;
				}
				}
			}
		
		}

	@Override
	public void changePassword(AccountDetails ad) {
		Scanner ss1 = new Scanner(System.in);
		System.out.println("Enter new password");
		ad.getUserTable().setLoginPassword(ss1.next());
		Connection con = getConnection();
		
		String sql1="update usertable set loginpassword=? where account_id=? & user_id=?";   //userId validation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setString(1, ad.getUserTable().getLoginPassword());
			ps.setInt(2, Integer.valueOf(ad.getAccount_ID().toString()));
			ps.setInt(3, Integer.valueOf(ad.getUserTable().getUserID()));
			Integer n= ps.executeUpdate();
			if(n>=1){
				System.out.println("Password changed!!\nNew password: "+ad.getUserTable().getLoginPassword());
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void createNewAccount(AccountDetails ad) {
		Scanner ss1 = new Scanner(System.in);
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		Date openDate= new Date();
		try {
			System.out.println("Enter name of customer");
			ad.getCustomerdetails().setCustomer_name(br.readLine());
			System.out.println("Enter address of customer");
			ad.getCustomerdetails().setAddress(br.readLine());
			//check for mobile number
			System.out.println("Enter email-id of customer");
			ad.getCustomerdetails().setEmail(br.readLine());
			System.out.println("Enter account type");
			ad.setAccountType(br.readLine());
			System.out.println("Enter opening balance for the account");
			ad.setAccountBalance(ss1.nextDouble());
			ad.setOpenDate(openDate);
			Connection con = getConnection();
			String sql1="select bank_account_id_seq.nextval from dual";   //create a sequence
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql1);
			  
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					ad.setAccount_ID(BigInteger.valueOf(rs.getInt(1)));
				}
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			String sql2="insert into account_master values(?,?,?,?) ";   
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql2);
				ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
				ps.setString(2,ad.getAccountType());
				ps.setDouble(3, ad.getAccountBalance());	
				ps.setDate(4, new java.sql.Date(ad.getOpenDate().getTime()));
				Integer n= ps.executeUpdate();
				if(n>=1){
					System.out.println("Account created \n"+"Account no. is "+ad.getAccount_ID());
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void viewAllTransactions() {
		Scanner s= new Scanner(System.in);
		System.out.println("Select choice for viewing transactions");
		System.out.println("1. Daily basis");
		System.out.println("2. Monthly basis");
		System.out.println("3.Yearly basis");
		Integer choice= s.nextInt();
		String sql=null;
		switch(choice){
		case 1: 
			{
				System.out.println("Enter date for which you want to see details");
				System.out.println("Date(format- dd/mm/yyyy)");
				String sdate= s.next();
				Date  ddate= null;
				try {
					ddate = new SimpleDateFormat("dd/mm/yyyy").parse(sdate);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				sql="select * from transactions where TO_DATE(TO_CHAR(DateOfTransaction, 'dd/mm/yyyy'), 'dd/mm/yyyy')=? order by Transaction_ID desc"; 
				try {
					Connection con = getConnection();
					PreparedStatement ps  = con.prepareStatement(sql);
					ps.setDate(1, new java.sql.Date(ddate.getTime()));
					ResultSet rs= ps.executeQuery();
					while(rs.next()){
						System.out.println("AccountID:"+rs.getInt(1));
						System.out.println("TransactionID:"+rs.getInt(2));
						System.out.println("Transaction description:"+rs.getString(3));
						System.out.println("Date of Transaction:"+rs.getDate(4));
						System.out.println("Transaction Type:"+rs.getString(5));
						System.out.println("Transaction Amount:"+rs.getDouble(6));
					}
					con.close();
				}	
				catch (SQLException e) {
					e.printStackTrace();
				}
				break;
		}
		case 2:{
			System.out.println("Enter month for which you want to see details");
			System.out.println("Month(Januray, februray, march, april, may, june ,july, august, september, october, november, december)");
			String smonth= s.next();
			sql="select * from transactions where DateOfTransaction Like ? order by Transaction_ID desc"; 
			try {
				Connection con = getConnection();
				PreparedStatement ps  = con.prepareStatement(sql);
				ps.setString(1,"%"+smonth.substring(0,3)+"%");
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					System.out.println("AccountID:"+rs.getInt(1));
					System.out.println("TransactionID:"+rs.getInt(2));
					System.out.println("Transaction description:"+rs.getString(3));
					System.out.println("Date of Transaction:"+rs.getDate(4));
					System.out.println("Transaction Type:"+rs.getString(5));
					System.out.println("Transaction Amount:"+rs.getDouble(6));
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			break;
			
		}
		case 3:{
			System.out.println("Enter year for which you want to see details");
			String syear= s.next();
			sql="select * from transactions where DateOfTransaction Like ? order by Transaction_ID desc"; 
			try {
				Connection con = getConnection();
				PreparedStatement ps  = con.prepareStatement(sql);
				ps.setString(1,"%"+syear+"%");
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					System.out.println("AccountID:"+rs.getInt(1));
					System.out.println("TransactionID:"+rs.getInt(2));
					System.out.println("Transaction description:"+rs.getString(3));
					System.out.println("Date of Transaction:"+rs.getDate(4));
					System.out.println("Transaction Type:"+rs.getString(5));
					System.out.println("Transaction Amount:"+rs.getDouble(6));
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			break;
			
		}	
			
		}
		
	}

}
