package com.cg.bean;

import java.util.Date;

public class TransactionDetails {
	private Integer transaction_ID;
	private String  tran_description;
	private Date dateOfTransaction = new Date();
	public Integer getTransaction_ID() {
		return transaction_ID;
	}
	public void setTransaction_ID(Integer transaction_ID) {
		this.transaction_ID = transaction_ID;
	}
	public String getTran_description() {
		return tran_description;
	}
	public void setTran_description(String tran_description) {
		this.tran_description = tran_description;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Double getTranAmount() {
		return tranAmount;
	}
	public void setTranAmount(Double tranAmount) {
		this.tranAmount = tranAmount;
	}
	private String transactionType;
	private Double tranAmount;
	
	
}
