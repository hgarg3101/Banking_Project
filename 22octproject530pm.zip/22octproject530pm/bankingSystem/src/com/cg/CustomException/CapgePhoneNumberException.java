package com.cg.CustomException;

public class CapgePhoneNumberException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String phonenumber;
	public CapgePhoneNumberException(String phonenumber){
		this.phonenumber=phonenumber;
	}
	public String toString() {
		return "Phonenumber is Invalid. Phone number should be 10 digits long and can only start with 9,8,7.";
		
	}
}	
