package com.cg.CustomException;

public class CapgeEmailException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String email;
	public CapgeEmailException (String email){
		this.email=email;
	}
	public String toString() {
		return "Email is Invalid. xyz@example.com";
		
	}
}
