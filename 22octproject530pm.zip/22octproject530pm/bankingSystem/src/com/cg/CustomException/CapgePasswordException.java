package com.cg.CustomException;

public class CapgePasswordException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String password;
	public CapgePasswordException (String password){
		this.password=password;
	}
	public String toString() {
		return "password is Invalid. Minimum 8 characters long";
		
	}
}

