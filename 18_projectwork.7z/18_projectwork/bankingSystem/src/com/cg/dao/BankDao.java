package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import com.cg.bean.AccountDetails;

public class BankDao implements IBankDao {
	public Connection getConnection(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
		try {
			return DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean login(Integer userID, String loginPassword) {
		boolean flag=false;
		Connection con = getConnection();
		String sql="select * from user_table where user_id=?";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setInt(1, userID);
		  //remember sequence needed
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				if(rs.getString(3).equals(loginPassword)){
					flag=true;	
				}
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return flag;
	}
	
	@Override
	public void miniStatement() {
		Connection con = getConnection();
		String sql="select * from transactions where rownum<=10 order by Transaction_ID desc";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
		  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void detailedStatement(Date from, Date to) {
		Connection con = getConnection();
		String sql="select * from transactions where TO_DATE(TO_CHAR(DateOfTransaction, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN ? AND ? order by Transaction_ID desc";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setDate(1, new java.sql.Date(from.getTime()));
			ps.setDate(2, new java.sql.Date(to.getTime()));
			  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void changeDetails(Integer userID) {
		Connection con = getConnection();
		Scanner ss= new Scanner(System.in);
		String sql1="select * from customer where account_id=(select account_id from user_table where user_id=?)";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, userID);
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("Email:"+rs.getString(3));
				System.out.println("Address:"+rs.getString(4));
			}
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
	String sql2= "update customer set email=?,address=? where account_id=(select account_id from user_table where user_id=?)";
	System.out.println("Enter new email");
	String newemail=ss.next();
	System.out.println("Enter new address");
	String newaddress=ss.next();
	try {
		PreparedStatement ps  = con.prepareStatement(sql2);
		ps.setString(1, newemail);
		ps.setString(2, newaddress);
		ps.setInt(3, userID);	
		Integer n= ps.executeUpdate();
		if(n>=1){
			System.out.println("New data updated");
		}
		con.close();
	}	
	catch (SQLException e) {
		e.printStackTrace();
	}
	}

	@Override
	public void chequeBookRequest(AccountDetails ad) {
		Date serviceRaisedDate = new Date();
		Connection con = getConnection();
		String sql1="select bank_cheque_seq.nextval from dual";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
		  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				ad.getServiceTracker().setService_ID(rs.getInt(1));
			}
			ad.getServiceTracker().setServiceDescription("cheque book request");
			ad.getServiceTracker().setServiceRaisedDate(serviceRaisedDate);
			ad.getServiceTracker().setServiceStatus("Open");
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sql2="insert into service_tracker values(?,?,?,?,?) ";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql2);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().toString()));
			ps.setInt(2,ad.getServiceTracker().getService_ID());
			ps.setString(3, ad.getServiceTracker().getServiceDescription());	
			ps.setDate(4, new java.sql.Date(ad.getServiceTracker().getServiceRaisedDate().getTime()));
			ps.setString(5, ad.getServiceTracker().getServiceStatus());
			Integer n= ps.executeUpdate();
			if(n>=1){
				System.out.println("service request generated");
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	

		
	}

	@Override
	public void trackServiceRequest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changePassword() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createNewAccount(AccountDetails ad) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAllTransactions() {
		// TODO Auto-generated method stub
		
	}





}
