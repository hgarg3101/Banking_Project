package com.cg.dao;

import java.util.Date;

import com.cg.bean.AccountDetails;

public interface IBankDao{
	public boolean login(Integer userID, String loginPassword);
	public void miniStatement();
	public void detailedStatement(Date from, Date to);
	public void changeDetails(Integer userID);
	public void chequeBookRequest(AccountDetails ad);
	public void trackServiceRequest();
	public void fundTransfer();
	public void changePassword();
	public void createNewAccount(AccountDetails ad);
	public void viewAllTransactions();
}
