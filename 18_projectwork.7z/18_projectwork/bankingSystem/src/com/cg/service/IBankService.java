package com.cg.service;

import com.cg.bean.AccountDetails;


public interface IBankService {
	
	public boolean login(Integer  userID, String loginPassword);
	public void viewStatement();
	public void changeDetails(Integer userID);
	public void chequeBookRequest(AccountDetails ad);
	public void trackServiceRequest();
	public void fundTransfer();
	public void changePassword();
	public void createNewAccount(AccountDetails ad);
	public void viewAllTransactions();
}
