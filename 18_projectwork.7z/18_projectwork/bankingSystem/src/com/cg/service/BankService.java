package com.cg.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.cg.bean.AccountDetails;
import com.cg.dao.BankDao;

import java.util.Date;

class ViewStatement{
	ViewStatement(BankDao bd){
		System.out.println("Choose a option \n");
		System.out.println("1--View Mini statement");
		System.out.println("2--View Detailed statement");
		Scanner ss = new Scanner(System.in);
		Integer n = ss.nextInt();
		
		//to view statements of all his/her accounts, incase of multiple accounts
		switch(n)
		{
			case 1: 
				bd.miniStatement();
				break;
			case 2:
				System.out.println("Enter range for dates");
				System.out.println("From Date(format- dd-mm-yyyy)");
				String fr= ss.next();
				System.out.println("TO Date(format- dd-mm-yyyy)");
				String t= ss.next();
				Date from = null;
				Date to = null;
			try {
				from = new SimpleDateFormat("dd-mm-yyyy").parse(fr);
				to=new SimpleDateFormat("dd-mm-yyyy").parse(t);
			} catch (ParseException e) {
				e.printStackTrace();
			}
				bd.detailedStatement(from,to);
				break;
			default:
		}
		ss.close();
	}
	public void miniStatement(){
	
	}
	public void detailedStatement(Date from, Date to){
		
	}
}

public class BankService implements IBankService{
	
	BankDao bd= new BankDao();
	@Override
	public boolean login(Integer  userID, String loginPassword) {
		
		return bd.login(userID, loginPassword);
	}

	@Override
	public void viewStatement() {
		ViewStatement vs = new ViewStatement(bd);
	}

	@Override
	public void changeDetails(Integer userID) {
		bd.changeDetails(userID);
		
	}

	@Override
	public void chequeBookRequest(AccountDetails ad) {
		bd.chequeBookRequest(ad);
		
	}

	@Override
	public void trackServiceRequest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer() {
		System.out.println("Choose a option \n");
		System.out.println("1--Own  bank account ");
		System.out.println("\n2--Other  account of same bank");
		Scanner ss1 = new Scanner(System.in);
		int n1 = ss1.nextInt();
		//to view statements of all his/her accounts, incase of multiple accounts
		switch(n1)
		{
			case 1: 
				//This accepts from Account and To account no   For fund transfer. 
				break;
			case 2:
				System.out.println("Make a Transfer");
				
				break;
			default:System.out.println("\nWrong choice. Choose between 1-2");
		}
		ss1.close();
		
		
	}

	@Override
	public void changePassword() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createNewAccount(AccountDetails ad) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAllTransactions() {
		// TODO Auto-generated method stub
		
	}

	



}
