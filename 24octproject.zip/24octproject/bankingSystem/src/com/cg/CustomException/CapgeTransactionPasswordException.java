package com.cg.CustomException;

public class CapgeTransactionPasswordException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String transactionpassword;
	public CapgeTransactionPasswordException (String transactionpassword){
		this.transactionpassword=transactionpassword;
	}
	public String toString() {
		return "Password must be 6 characters long. Ex: 123xyz";
		
	}
}
