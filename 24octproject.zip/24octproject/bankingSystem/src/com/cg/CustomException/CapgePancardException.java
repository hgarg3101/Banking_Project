package com.cg.CustomException;

public class CapgePancardException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String pancard;
	public CapgePancardException (String pancard){
		this.pancard=pancard;
	}
	public String toString() {
		return "Pancard no. is in invalid format. Ex:-ABCDE1234E";
		
	}
}
