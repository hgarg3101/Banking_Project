package com.cg.dao;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.CustomException.*;
import com.cg.bean.AccountDetails;


public class BankDao implements IBankDao {
	
	static Logger Log=Logger.getLogger(BankDao.class.getName()); 
	
	public Connection getConnection(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
		try {
			return DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean login(Integer userID, String loginPassword,AccountDetails ad) {
		Log.info("inside login function");
		boolean flag=false;
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		StringBuffer checkpassword= new StringBuffer();
		Connection con = getConnection();
		String sql1="select * from user_table where user_id=?";   //userId validation
		Integer count=3;
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, userID);
		  //remember sequence needed
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
				ad.getAccount_ID().add((BigInteger.valueOf(rs.getInt(1))));
				ad.getUserTable().setUserID(userID.toString());
				ad.getUserTable().setSecretQuestion(rs.getString(4));
				ad.getUserTable().setTransactionPassword(rs.getString(5));
				ad.getUserTable().setLockStatus(rs.getString(6));
				
				if(ad.getUserTable().getLockStatus().toUpperCase().equals(String.valueOf('N'))){
					System.out.println("Your account is locked!! Contact to three eyed raven to unlock the door");
					
					System.exit(0);
				}
				
				if(rs.getString(3).equals(loginPassword)){
					ad.getUserTable().setLoginPassword(loginPassword);
					//change here //it should be array multiple account
					flag=true;
				}
				else {
					while(true) {
						
						if(rs.getString(3).equals(checkpassword.toString())){
							ad.getUserTable().setLoginPassword(checkpassword.toString());
							//change here //it should be array multiple account
							flag=true;
							break;
						}
					
					if(count==0){
						try {
							String sql="update user_table set lock_status=? where account_id=? AND user_id=?";
							PreparedStatement ps1= con.prepareStatement(sql);
							ps1.setString(1, "N");
							
//							ad.getAccount_ID().add((BigInteger.valueOf(rs.getInt(1))));
//							Integer.valueOf(ad.getAccount_ID().get(0).toString())
							
							
							ps1.setInt(2,Integer.valueOf(ad.getAccount_ID().get(0).toString()));
							ps1.setInt(3,Integer.valueOf(ad.getUserTable().getUserID().toString()));
							Integer n= ps1.executeUpdate();
							if(n>=1) {
								System.out.println("Account locked!!! \n You have entered wrong password 3 times.");
							//add secret question code here
								
							}
							con.close();
						}
						catch(Exception e) {
							e.printStackTrace();
						}
						
					}
					if(count==3){
						Character chforget=null;
						System.out.println("If forget password enter y/n");
						try {
							chforget=Character.valueOf(br.readLine().charAt(0));
						} catch (IOException e) {
							e.printStackTrace();
						}
						if(chforget.toString().toUpperCase().equals(String.valueOf("Y"))) {
						return false;
						}
					}
					else if(count>0) {
						count--;
						checkpassword.delete(0, checkpassword.length());
						
						System.out.println("Enter password again");
						try {
							checkpassword.append(br.readLine());
						} catch (IOException e) {
							e.printStackTrace();
						}
						continue;
					}
				}
			}
			
		}
		else{
				System.out.println("User id not found!!!");
				System.exit(0);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		//home
		
		String sql2="select * from account_master where account_id=?";  
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql2);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				ad.setAccountType(rs.getString(2));
				ad.setAccountBalance(rs.getDouble(3));
				ad.setOpenDate(rs.getDate(4));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		//add code to retrieve account id for multiple account from customer table using user table
		
		
		return flag;
	}
	
	@Override
	public void miniStatement(AccountDetails ad) {
		Connection con = getConnection();
		String sql="select * from transactions where rownum<=10 and account_id=? order by Transaction_ID desc";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void detailedStatement(Date from, Date to,AccountDetails ad) {
		Connection con = getConnection();
		System.out.println("from date "+from+" to date "+to);
		String sql="select * from transactions where account_id=? and TO_DATE(TO_CHAR(DateOfTransaction, 'dd-mm-yyyy'), 'dd-mm-yyyy') BETWEEN ? AND ?order by Transaction_ID desc";   //userId vcaldiation
		  
		try {
			PreparedStatement ps  = con.prepareStatement(sql);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ps.setDate(2, new java.sql.Date(from.getTime()));
			ps.setDate(3, new java.sql.Date(to.getTime()));
			  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("TransactionID:"+rs.getInt(2));
				System.out.println("Date of Transaction:"+rs.getDate(4));
				System.out.println("Transaction Type:"+rs.getString(5));
				System.out.println("Transaction Amount:"+rs.getDouble(6));
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void changeDetails(AccountDetails ad) {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		StringBuffer newphonenumber= new StringBuffer();
		StringBuffer newemail= new StringBuffer();
		Connection con = getConnection();
		Scanner ss= new Scanner(System.in);
		String sql1="select * from customer where account_id=(select account_id from user_table where user_id=?)";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, Integer.valueOf(ad.getUserTable().getUserID()));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				System.out.println("Email:"+rs.getString(3));
				System.out.println("Address:"+rs.getString(4));
			}
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		//add phone number column in database
	String sql2= "update customer set email=?,address=?, phonenumber=? where account_id=?";
	while(true){
	System.out.println("Enter new email");
	try {
		newemail.delete(0, newemail.length());
		newemail.append(br.readLine());
	} catch (IOException e1) {
		e1.printStackTrace();
	}
	try {
	//	[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$
		if(!newemail.toString().matches("[A-Za-z0-9._%+-]{1,}[@][A-Za-z0-9]{1,}[.][A-Za-z]{2,4}")) {
			throw new CapgeEmailException(newemail.toString());
		}
	}
	catch(CapgeEmailException e) {
		e.printStackTrace();
		continue;
	}
	break;
	}
	System.out.println("Enter new address");
	String newaddress=ss.next();
	while(true){
	System.out.println("Enter new phone number");
	try {
		newphonenumber.delete(0,newphonenumber.length());
		newphonenumber.append(br.readLine());
	} catch (IOException e1) {
		e1.printStackTrace();
	}
	try {
		if(!newphonenumber.toString().matches("[987]{3}[0-9]{7}")) {
			throw new CapgePhoneNumberException(newphonenumber.toString());
		}
			
	}
	catch(CapgePhoneNumberException e) {
		e.printStackTrace();
		continue;
	}
	break;
	}
	try {
		PreparedStatement ps  = con.prepareStatement(sql2);
		ps.setString(1, newemail.toString());
		ps.setString(2, newaddress);
		ps.setString(3, newphonenumber.toString());
		ps.setInt(4, Integer.valueOf(ad.getAccount_ID().get(0).toString()));	
		Integer n= ps.executeUpdate();
		if(n>=1){
			System.out.println("New data updated");
		}
		con.close();
	}	
	catch (SQLException e) {
		e.printStackTrace();
	}
	ss.close();
	}

	@Override
	public void chequeBookRequest(AccountDetails ad) {
		Date serviceRaisedDate = new Date();
		Connection con = getConnection();
		String sql1="select bank_cheque_seq.nextval from dual";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
		  
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				ad.getServiceTracker().setService_ID(rs.getInt(1));
			}
			ad.getServiceTracker().setServiceDescription("cheque book request");
			ad.getServiceTracker().setServiceRaisedDate(serviceRaisedDate);
			ad.getServiceTracker().setServiceStatus("Open");
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sql2="insert into service_tracker values(?,?,?,?,?) ";   //userId vcaldiation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql2);
			ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ps.setInt(2,ad.getServiceTracker().getService_ID());
			ps.setString(3, ad.getServiceTracker().getServiceDescription());	
			ps.setDate(4, new java.sql.Date(ad.getServiceTracker().getServiceRaisedDate().getTime()));
			ps.setString(5, ad.getServiceTracker().getServiceStatus());
			Integer n= ps.executeUpdate();
			if(n>=1){
				System.out.println("service request generated. Your sevice request id is "+ad.getServiceTracker().getService_ID());
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	

		
	}

	@Override
	public void trackServiceRequest(AccountDetails ad) {
		Scanner ss= new Scanner(System.in);
		Connection con = getConnection();
		String check=null;
		  //userId validation
		
		try {
			
			System.out.println("Do you remember service id.\nEnter y/n");
			check=ss.next();
			if(!"Y".equals(check.toUpperCase())) {
				String sql="select * from service_tracker where account_id=? and (to_date(sysdate, 'dd-mm-yyyy') - to_date(service_raised_date, 'dd-mm-yyyy'))<180 ";
				//code here related to latest 20
				PreparedStatement ps1  = con.prepareStatement(sql);
				System.out.println("Enter account id");
				ps1.setInt(1, Integer.valueOf((ss.next())));
				ResultSet rs1= ps1.executeQuery();
				while(rs1.next()){
					System.out.println("service status for "+rs1.getInt(2)+" is "+rs1.getString(5));
					
				}
			}
			
			System.out.println("Please enter service request id");
			
			String sql1="select * from service_tracker where service_id=? and account_id=?"; 
			
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setInt(1, Integer.valueOf((ss.next())));
			ps.setInt(2, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
				System.out.println("service status for "+rs.getInt(2)+" is "+rs.getString(5));
				
			}
			
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		ss.close();
	}

	@Override
	public void fundTransfer(AccountDetails ad) {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nMake a Transfer\n\n");
		System.out.println("Choose a option \n");
		System.out.println("1--Add a Payee ");
		System.out.println("2--Pay to payee");
		
		try {
		Integer	n2 = Integer.valueOf(br.readLine());
			switch(n2) {
			case 1:{
				System.out.println("Enter payee account id ");
				String payee= br.readLine();
				System.out.println("Ener nick name for payee");
				String nick = br.readLine();
				Connection con = getConnection();
				String sql1="select * from payee_table where account_id=? and payee_account_id=?";

				try {
					PreparedStatement ps  = con.prepareStatement(sql1);
					ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
					ps.setInt(2,Integer.valueOf(payee) );
					ResultSet rs= ps.executeQuery();
					if(rs.next()){
							System.out.println("Payee account id already exist for your account");
							break;
						
					}
					else {
						String sql2="insert into payee_table values(?,?,?)";   //userId validation
						
							PreparedStatement ps2  = con.prepareStatement(sql2);
							ps2.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
							ps2.setInt(2,Integer.valueOf(payee));
							ps2.setString(3,nick);
							Integer n= ps2.executeUpdate();
							if(n>=1){
								System.out.println("1 row updated in payee table");
							}
						//i said meaningless that time..else code was here with nothing inside
							con.close();
					}
				}	
				catch (SQLException e) {
					e.printStackTrace();
				}
			break;
			}
			case 2:{
				boolean flag=false;
				Connection con = getConnection();
				System.out.println("Enter payee account id ");
				ad.getPayeeTable().setPayeeAccountID(BigInteger.valueOf(Long.valueOf(br.readLine())));
				
				
				
				{
				//check payee id validation
				
					String sql="select * from payee_table where account_id=? and payee_account_id=?";

					try {
						PreparedStatement ps  = con.prepareStatement(sql);
						ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
						ps.setInt(2, Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
						ResultSet rs= ps.executeQuery();
						if(!rs.next()){
								System.out.println("Payee account id does not exist.\n Add payee account id");
								System.exit(0);
						}
					}	
					catch (SQLException e) {
						e.printStackTrace();
					}
				
				
				}
				
				while(true){
				System.out.println("Enter the transaction amount: ");
				ad.getTransactiondetails().setTranAmount(Double.valueOf(br.readLine()));
				
				//validation for transaction amount 10lakh
				
				{
					
					String sql="select sum(TranAmount) from transactions where account_id=? and TO_Date(DateOfTransaction, 'dd-MM-yyyy') LIKE TO_Date(?, 'dd-MM-yyyy') and TransactionType=?";

					try {
						PreparedStatement ps  = con.prepareStatement(sql);
						ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
						ps.setDate(2, new java.sql.Date(new Date().getTime()));
						ps.setString(3, "D");
						ResultSet rs= ps.executeQuery();
						while(rs.next()){
								if((rs.getDouble(1)+ad.getTransactiondetails().getTranAmount())>1000000){
									System.out.println("Transaction not possible. Limit exceeded. Only 10 lakh per day is allowed.");
									System.out.println("You can do transaction for Rs. "+(1000000-rs.getDouble(1))+" only");
									flag=true;
								}
						}
						if(flag){
							continue;
						}
					}	
					catch (SQLException e) {
						e.printStackTrace();
					}	
					
				}
				break;
				}
				System.out.println("Enter the transaction password: ");
				String tpass=br.readLine();
				if(!(ad.getUserTable().getTransactionPassword()).equals(tpass)) {
					System.out.println("Wrong password!!! ");
					System.exit(0);
				}
				else{
					
					//pay the payee
					//validation to check balance in account
					try {
						if(ad.getTransactiondetails().getTranAmount()>ad.getAccountBalance()) {
							System.out.println("Insufficient balance!! You have Rs."+ad.getAccountBalance()+" only in your account");		
						}
						else {
							
							
							String sql1="select * from account_master where account_id=?";
							PreparedStatement ps1= con.prepareStatement(sql1);
							ps1.setInt(1,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
							ResultSet rs= ps1.executeQuery();
							if(rs.next()) {
								
								
								{
									Date tdate= new Date();
									ad.getTransactiondetails().setDateOfTransaction(tdate);
									//sequence for t_id
									{
										String sql6="select bank_transaction_id_seq.nextval from dual";   //create a sequence
										
									
											PreparedStatement ps  = con.prepareStatement(sql6);
										  
											ResultSet rs1= ps.executeQuery();
											while(rs1.next()){
												ad.getTransactiondetails().setTransaction_ID(rs.getInt(1));
											}
											
										
									}
							
									
									
									//details for debited  account
								
									String sql4="insert into transactions values(?,?,?,?,?,?)";
									PreparedStatement ps4= con.prepareStatement(sql4);
									ps4.setInt(1,Integer.valueOf(ad.getAccount_ID().get(0).toString()));
									ad.getTransactiondetails().setTransactionType("D");
									ps4.setInt(2,ad.getTransactiondetails().getTransaction_ID());
					
									ad.getTransactiondetails().setTran_description(ad.getTransactiondetails().getTranAmount()+" amount debited");
									ps4.setString(3,ad.getTransactiondetails().getTran_description());
									ps4.setDate(4,new java.sql.Date(tdate.getTime()) );
									ps4.setString(5,ad.getTransactiondetails().getTransactionType());
									ps4.setDouble(6, ad.getTransactiondetails().getTranAmount());
									ps4.executeUpdate();
									
									
									//details for credited account 
									
									/*{
										String sql7="select bank_transaction_id_seq.nextval from dual";   //create a sequence
										
									
											PreparedStatement ps  = con.prepareStatement(sql7);
										  
											ResultSet rs1= ps.executeQuery();
											while(rs1.next()){
												ad.getTransactiondetails().setTransaction_ID(rs.getInt(1));
											}
									}
									
									*/
									String sql5="insert into transactions values(?,?,?,?,?,?)";
									PreparedStatement ps5= con.prepareStatement(sql5);
									ps5.setInt(1,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
									ad.getTransactiondetails().setTransactionType("C");
									ps5.setInt(2,ad.getTransactiondetails().getTransaction_ID());
									ad.getTransactiondetails().setTran_description(ad.getTransactiondetails().getTranAmount()+" amount credited");
									ps5.setString(3,ad.getTransactiondetails().getTran_description());
									ps5.setDate(4,new java.sql.Date(tdate.getTime()) );
									ps5.setString(5,ad.getTransactiondetails().getTransactionType());
									ps5.setDouble(6, ad.getTransactiondetails().getTranAmount());
									ps5.executeUpdate();
									
								}
								
								ad.setAccountBalance(ad.getAccountBalance()-ad.getTransactiondetails().getTranAmount()); //deducting amount for payment
								ad.getTransactiondetails().setTranAmount(ad.getTransactiondetails().getTranAmount()+rs.getDouble(3)); //adding amount for payment
							
							}

							String sql2="update Account_Master set account_balance=? where account_id=?";
							PreparedStatement ps2= con.prepareStatement(sql2);
							ps2.setDouble(1, ad.getTransactiondetails().getTranAmount());
							ps2.setInt(2,Integer.valueOf(ad.getPayeeTable().getPayeeAccountID().toString()));
							Integer n= ps2.executeUpdate();
							if(n>=1) {
								System.out.println("Amount added to payee account");
							}
						
							String sql3="update Account_Master set account_balance=? where account_id=?";
							PreparedStatement ps3= con.prepareStatement(sql3);
							ps3.setDouble(1, ad.getAccountBalance());
							ps3.setInt(2,Integer.valueOf(ad.getAccount_ID().get(0).toString()));
							Integer n3= ps3.executeUpdate();
							if(n3>=1) {
								System.out.println("Amount deducted from your account");
							}
							
							
							con.close();
						}
						//deduct amount code
						
						
					}
					catch(Exception e) {
						e.printStackTrace();
						}
					}
				}	
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} 
		
		}

	@Override
	public void changePassword(AccountDetails ad) {
		Scanner ss1 = new Scanner(System.in);
		while(true) {
		System.out.println("Enter new password");
		String newpassword=ss1.next();
		ad.getUserTable().setLoginPassword(newpassword);
		////
		try {
			if(!newpassword.matches("[A-Za-z0-9]{8,}")) {
				throw new CapgePasswordException(newpassword);
			}
				
		}
		catch(CapgePasswordException e) {
			e.printStackTrace();
			continue;
		}
		break;
		}
		Connection con = getConnection();
		
		String sql1="update user_table set login_password=? where account_id=? and user_id=?";   //userId validation
		
		try {
			PreparedStatement ps  = con.prepareStatement(sql1);
			ps.setString(1, ad.getUserTable().getLoginPassword());
			ps.setInt(2, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
			ps.setInt(3, Integer.valueOf(ad.getUserTable().getUserID()));
			Integer n= ps.executeUpdate();
			if(n>=1){
				System.out.println("Password changed!!\nNew password: "+ad.getUserTable().getLoginPassword());
			}
			con.close();
		}	
		catch (SQLException e) {
			e.printStackTrace();
		}
		ss1.close();
		
	}

	@Override
	public void createNewAccount(AccountDetails ad) {
		Scanner ss1 = new Scanner(System.in);
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		Date openDate= new Date();
		try {
			System.out.println("Enter name of customer");
			ad.getCustomerdetails().setCustomer_name(br.readLine());
			System.out.println("Enter email-id of customer");
			ad.getCustomerdetails().setEmail(br.readLine());
			System.out.println("Enter address of customer");
			ad.getCustomerdetails().setAddress(br.readLine());
			while(true){
			System.out.println("Enter pancard of customer");
			ad.getCustomerdetails().setPancard(br.readLine());
			try {
				//	[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$
					if(!ad.getCustomerdetails().getPancard().matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
						throw new CapgePancardException(ad.getCustomerdetails().getPancard());
					}
				}
				catch(CapgePancardException e) {
					e.printStackTrace();
					continue;
				}
			break;
			}
			
			while(true){
				System.out.println("Enter phonenumber of customer");
				ad.getCustomerdetails().setPhonenumber(br.readLine());
				try {
					//	
						if(!ad.getCustomerdetails().getPhonenumber().matches("[0-9]{10}")) {
							throw new CapgePhoneNumberException(ad.getCustomerdetails().getPhonenumber());
						}
					}
					catch(CapgePhoneNumberException e) {
						e.printStackTrace();
						continue;
					}
				break;
				}
			
			
			//check for mobile number
			System.out.println("Enter account type");
			ad.setAccountType(br.readLine());
			
			while(true){
				System.out.println("Enter account type..(Savings/Current");
				ad.setAccountType(br.readLine());
				if(ad.getAccountType().equalsIgnoreCase("Savings")||ad.getAccountType().equalsIgnoreCase("Current")) {
					break;
				}	
				else{
					System.out.println("Wrong input!!\n");
						continue;
					}
			
				}
			
			
			System.out.println("Enter opening balance for the account");
			ad.setAccountBalance(ss1.nextDouble());
			ad.setOpenDate(openDate);
			
			while(true){
			System.out.println("Enter user_id for customer");
			ad.getUserTable().setUserID(br.readLine());
			{
				//check for user id
				Connection con = getConnection();
				String sql1="select * from user_table where user_id=?"; 
				try {
					PreparedStatement ps  = con.prepareStatement(sql1);
					ps.setString(1,(ad.getUserTable().getUserID()));
					ResultSet rs= ps.executeQuery();
					if(rs.next()){
						System.out.println("user already exist");
						continue;
					}
					else{
						break;
					}
				}
				catch( Exception e){
					e.printStackTrace();
					}
				}
			}
			ad.getUserTable().setLoginPassword("heyperson");
			System.out.println("Enter answer for secret question.");
			System.out.println("Question is: Why bahubali killed kattappa??");
			ad.getUserTable().setSecretQuestion(br.readLine());
			
			
			while(true){
				System.out.println("Enter transaction password of user");
				ad.getUserTable().setTransactionPassword(br.readLine());
				try {
					//	[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$
						if(!ad.getUserTable().getTransactionPassword().matches("[A-Za-z0-9]{6}")) {
							throw new CapgeTransactionPasswordException(ad.getUserTable().getTransactionPassword());
						}
					}
					catch(CapgeTransactionPasswordException e) {
						e.printStackTrace();
						continue;
					}
				break;
				}
			ad.getUserTable().setLockStatus("y");
			
			
			Connection con = getConnection();
			
			String sql1="select bank_account_id_seq.nextval from dual";   //create a sequence
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql1);
			  
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					ad.getAccount_ID().add((BigInteger.valueOf(rs.getInt(1))));
				}
				
				
//				ad.getAccount_ID().add((BigInteger.valueOf(rs.getInt(1))));
//				Integer.valueOf(ad.getAccount_ID().get(0).toString())
				
				
				
				
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			String sql2="insert into account_master values(?,?,?,?) ";   
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql2);
				ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
				ps.setString(2,ad.getAccountType());
				ps.setDouble(3, ad.getAccountBalance());	
				ps.setDate(4, new java.sql.Date(ad.getOpenDate().getTime()));
				Integer n= ps.executeUpdate();
				if(n>=1){
					System.out.println("Account created \n"+"Account no. is "+ad.getAccount_ID().get(0));
				}
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			String sql3="insert into customer values(?,?,?,?,?,?) ";   
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql3);
				ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
				ps.setString(2,ad.getCustomerdetails().getCustomer_name());
				ps.setString(3, ad.getCustomerdetails().getEmail());
				ps.setString(4, ad.getCustomerdetails().getAddress());
				ps.setString(5, ad.getCustomerdetails().getPancard());
				ps.setString(6, ad.getCustomerdetails().getPhonenumber());
				Integer n= ps.executeUpdate();
				if(n>=1){
					System.out.println("customer details added to database");
				}
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			String sql4="insert into user_table values(?,?,?,?,?,?) ";   
			
			try {
				PreparedStatement ps  = con.prepareStatement(sql4);
				ps.setInt(1, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
				ps.setString(2,ad.getUserTable().getUserID());
				ps.setString(3, ad.getUserTable().getLoginPassword());
				ps.setString(4, ad.getUserTable().getSecretQuestion());
				ps.setString(5, ad.getUserTable().getTransactionPassword());
				ps.setString(6, ad.getUserTable().getLockStatus());
				Integer n= ps.executeUpdate();
				if(n>=1){
					System.out.println("User details added.\nUser id:"+ad.getUserTable().getUserID());
					System.out.println("Login password: "+ad.getUserTable().getLoginPassword());
					System.out.println("transaction password: "+ad.getUserTable().getTransactionPassword());
					
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			

			
		} catch (IOException e) {
			e.printStackTrace();
		}
		ss1.close();
	}

	@Override
	public void viewAllTransactions() {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		Scanner s= new Scanner(System.in);
		System.out.println("Select choice for viewing transactions");
		System.out.println("1. Daily basis");
		System.out.println("2. Monthly basis");
		System.out.println("3. Yearly basis");
		Integer choice= s.nextInt();
		String sql=null;
		switch(choice){
		case 1: 
			{
				System.out.println("Enter date for which you want to see details");
				System.out.println("Date(format- dd-mm-yyyy)");
				String sdate = null;
				try {
					sdate = br.readLine();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				Date  ddate= null;
				try {
					ddate = new SimpleDateFormat("dd-MM-yyyy").parse(sdate);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				sql="select * from transactions where TO_Date(DateOfTransaction, 'dd-MM-yyyy') like to_date(?, 'dd-MM-yyyy') order by Transaction_ID desc"; 
				try {
					Connection con = getConnection();
					PreparedStatement ps  = con.prepareStatement(sql);
					ps.setDate(1, new java.sql.Date(ddate.getTime()));
					ResultSet rs= ps.executeQuery();
					while(rs.next()){
						System.out.println("AccountID:"+rs.getInt(1));
						System.out.println("TransactionID:"+rs.getInt(2));
						System.out.println("Transaction description:"+rs.getString(3));
						System.out.println("Date of Transaction:"+rs.getDate(4));
						System.out.println("Transaction Type:"+rs.getString(5));
						System.out.println("Transaction Amount:"+rs.getDouble(6));
					}
					con.close();
				}	
				catch (SQLException e) {
					e.printStackTrace();
				}
				break;
		}
		case 2:{
			System.out.println("Enter month for which you want to see details");
			System.out.println("Month(January, february, march, april, may, june ,july, august, september, october, november, december)");
			String smonth= s.next();
			sql="select * from transactions where DateOfTransaction Like ? order by Transaction_ID desc"; 
			try {
				Connection con = getConnection();
				PreparedStatement ps  = con.prepareStatement(sql);
				ps.setString(1,"%"+smonth.substring(0,3).toUpperCase()+"%");
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					System.out.println("AccountID:"+rs.getInt(1));
					System.out.println("TransactionID:"+rs.getInt(2));
					System.out.println("Transaction description:"+rs.getString(3));
					System.out.println("Date of Transaction:"+rs.getDate(4));
					System.out.println("Transaction Type:"+rs.getString(5));
					System.out.println("Transaction Amount:"+rs.getDouble(6));
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			break;
			
		}
		case 3:{
			System.out.println("Enter year for which you want to see details");
			String syear= s.next();
			sql="select * from transactions where TO_char(DateOfTransaction,'dd-mm-yyyy') Like ? order by Transaction_ID desc"; 
			try {
				Connection con = getConnection();
				PreparedStatement ps  = con.prepareStatement(sql);
				ps.setString(1,"%"+syear+"%");
				ResultSet rs= ps.executeQuery();
				while(rs.next()){
					System.out.println("AccountID:"+rs.getInt(1));
					System.out.println("TransactionID:"+rs.getInt(2));
					System.out.println("Transaction description:"+rs.getString(3));
					System.out.println("Date of Transaction:"+rs.getDate(4));
					System.out.println("Transaction Type:"+rs.getString(5));
					System.out.println("Transaction Amount:"+rs.getDouble(6));
				}
				con.close();
			}	
			catch (SQLException e) {
				e.printStackTrace();
			}
			break;
			
		}	
			
		}
		s.close();
	}

	@Override
	public boolean forgetPassword(AccountDetails ad,String secretanswer) {
		boolean flag=false;
		if(ad.getUserTable().getSecretQuestion().equals(secretanswer)) {
			ad.getUserTable().setLoginPassword("heyperson");   //dummy password
			Connection con= getConnection();
			try {
				String sql="update user_table set login_Password=? where account_id=? and user_id=?";
				PreparedStatement ps1= con.prepareStatement(sql);
				ps1.setString(1, ad.getUserTable().getLoginPassword());
				ps1.setInt(2, Integer.valueOf(ad.getAccount_ID().get(0).toString()));
				ps1.setInt(3,Integer.valueOf(ad.getUserTable().getUserID().toString()));
				Integer n= ps1.executeUpdate();
				if(n>=1) {
					System.out.println("Your new password is 'heyperson' use this to login and change your password");
					flag=true;
				
				}
				con.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		return flag;
	}
}