package com.cg.service;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.cg.bean.AccountDetails;

public class Myjunit {

	@Test
	public void testforvalidlogin() throws SQLException {
		AccountDetails ad = new AccountDetails();
		ad.getUserTable().setUserID("868");
		ad.getUserTable().setLoginPassword("harshit123");
		BankService bs= new BankService();
		assertEquals(true, bs.login(Integer.valueOf(ad.getUserTable().getUserID()), ad.getUserTable().getLoginPassword(), ad));   //should return 0 because fail
	}
	@Test
	public void testforforgetpassword() throws SQLException {
		AccountDetails ad = new AccountDetails();
		ad.getUserTable().setUserID("868");
		ad.getUserTable().setLoginPassword("harshit123");
		BankService bs= new BankService();
		bs.login(Integer.valueOf(ad.getUserTable().getUserID()), ad.getUserTable().getLoginPassword(), ad);
		assertEquals(false,bs.forgetPassword(ad, "wrong") );  //true will change password
	}
	

}
