package com.cg.bean;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;

public class AccountDetails {
	ArrayList<BigInteger> account_ID = new ArrayList<BigInteger>(); 
	private String accountType;
	private Double accountBalance;
	private Date openDate= new Date();
	private CustomerDetails customerdetails=new CustomerDetails();
	private TransactionDetails transactiondetails=new TransactionDetails();
	private FundTransfer fundTransfer=new FundTransfer();
	private ServiceTracker serviceTracker=new ServiceTracker();
	private UserTable userTable=new UserTable();
	private PayeeTable payeeTable= new PayeeTable();
	
	
	public ArrayList<BigInteger> getAccount_ID() {
		return account_ID;
	}
	public void setAccount_ID(ArrayList<BigInteger> account_ID) {
		this.account_ID = account_ID;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public CustomerDetails getCustomerdetails() {
		return customerdetails;
	}
	public void setCustomerdetails(CustomerDetails customerdetails) {
		this.customerdetails = customerdetails;
	}
	public TransactionDetails getTransactiondetails() {
		return transactiondetails;
	}
	public void setTransactiondetails(TransactionDetails transactiondetails) {
		this.transactiondetails = transactiondetails;
	}
	public FundTransfer getFundTransfer() {
		return fundTransfer;
	}
	public void setFundTransfer(FundTransfer fundTransfer) {
		this.fundTransfer = fundTransfer;
	}
	public ServiceTracker getServiceTracker() {
		return serviceTracker;
	}
	public void setServiceTracker(ServiceTracker serviceTracker) {
		this.serviceTracker = serviceTracker;
	}
	public UserTable getUserTable() {
		return userTable;
	}
	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}
	public PayeeTable getPayeeTable() {
		return payeeTable;
	}
	public void setPayeeTable(PayeeTable payeeTable) {
		this.payeeTable = payeeTable;
	}
	
}
