package com.cg.bean;

import java.util.Date;

public class ServiceTracker {
	private Integer service_ID;
	private String serviceDescription;
	private Date serviceRaisedDate=new Date();
	private String serviceStatus;
	
	public Integer getService_ID() {
		return service_ID;
	}
	public void setService_ID(Integer service_ID) {
		this.service_ID = service_ID;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	
}
