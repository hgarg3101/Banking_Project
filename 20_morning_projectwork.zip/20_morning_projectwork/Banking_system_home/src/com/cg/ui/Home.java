package com.cg.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

import com.cg.bean.AccountDetails;
import com.cg.service.BankService;

public class Home 
{
	public static void main(String arg[]) throws IOException
	{
		Integer choice;
		Character chforget='n';
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		BankService bs= new BankService();
		AccountDetails ad= new AccountDetails();
		while(true){
		System.out.println("Login Details:");
		System.out.println("Enter the username");
		String userID=br.readLine();
		System.out.println("Enter the password");
		String loginPassword=br.readLine();	
		if("admin".equals(userID) && "admin".equals(loginPassword)){
			System.out.println("Choose a option \n");
			System.out.println("1--Create New Account :");
			System.out.println("2--View transactions of all accounts");
			Integer choiceadmin;
			choiceadmin=Integer.valueOf(br.readLine());
			switch(choiceadmin)
			{
			case 1: 
				bs.createNewAccount(ad);
				break;
			case 2:
			    bs.viewAllTransactions();
				break;
			default:
				System.out.println("\nWrong choice. Choose between 1-2");
				System.out.println("system shutting down***");
				System.exit(0);
			}
		}
		else if(!bs.login(Integer.valueOf(userID), loginPassword,ad)){
			System.out.println("Invalid user!!\n\n");
			System.out.println("If forget password enter y/n");
			chforget=Character.valueOf(br.readLine().charAt(0));
			if(chforget.toString().toUpperCase()=="Y") {
				System.out.println("Enter answer for secret question");
				String secretanswer= br.readLine();
				System.out.println("Question is: Why bahubali killed kattappa??");
				if(!bs.forgetPassword(ad,secretanswer)) {
					System.out.println("Wrong answer!!");
					System.out.println("system shutting down***");
					System.exit(0);
				}
			}
			continue;
		}
		else{
			ad.getUserTable().setUserID(userID);
			break;
		}
		}
		System.out.println("welcome");
		System.out.println("\n\nChoose a option \n");
		System.out.println("1--View Mini/Detailed statement");
		System.out.println("2--Change in address/mobile number");
		System.out.println("3--Request for cheque book");
		System.out.println("4--Track service request");
		System.out.println("5--Fund Transfer");
		System.out.println("6--Change password");
		
		choice=Integer.valueOf(br.readLine());
		switch(choice)
		{
		case 1: 
			bs.viewStatement(ad);
			break;
		case 2:
			bs.changeDetails(ad);
			break;
		case 3: 
			bs.chequeBookRequest(ad);
			break;
		case 4:
			bs.trackServiceRequest(ad);
			break;
		case 5: 
			bs.fundTransfer(ad);		
			break;
		case 6:
			bs.changePassword(ad);
			break;
			
		default:System.out.println("\nWrong choice. Choose between 1-6");	
		}
	}
}
